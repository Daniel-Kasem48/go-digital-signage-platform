// Promotional Template Logic
class PromotionalDisplay {
    constructor() {
        this.countdownDate = new Date();
        this.countdownDate.setDate(this.countdownDate.getDate() + 3);
        this.loadModel();
    }

    async loadModel() {
        try {
            const response = await fetch('./model.json');
            const modelData = await response.json();
            this.modelConfig = modelData;
            this.init();
        } catch (error) {
            console.error('Error loading model.json:', error);
            this.modelConfig = {};
            this.init();
        }
    }

    init() {
        this.updateContent();
        this.startCountdown();
        this.addAnimations();
    }

    updateContent() {
        // Get data from model.json configuration
        const config = this.modelConfig || {};
        
        document.getElementById('product_name').textContent = config.product_name || 'Premium Digital Display';
        document.getElementById('price').textContent = config.price || '$299.99';
        document.getElementById('discount').textContent = config.discount || '25% OFF';
        document.getElementById('description').textContent = config.description || 'High-resolution 4K display with smart connectivity.';
        document.getElementById('call_to_action').textContent = config.call_to_action || 'Visit our showroom today!';
        
        // Calculate original price
        if (config.price && config.discount) {
            const currentPrice = parseFloat(config.price.replace('$', ''));
            const discountPercent = parseInt(config.discount.replace('%', '').replace(' OFF', ''));
            const originalPrice = currentPrice / (1 - discountPercent / 100);
            document.getElementById('original_price').textContent = `$${originalPrice.toFixed(2)}`;
        }
    }

    startCountdown() {
        const countdown = () => {
            const now = new Date().getTime();
            const distance = this.countdownDate - now;

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

            document.getElementById('countdown').textContent = `${days}d ${hours}h ${minutes}m`;

            if (distance < 0) {
                document.getElementById('countdown').textContent = "EXPIRED";
            }
        };

        countdown();
        setInterval(countdown, 60000); // Update every minute
    }

    addAnimations() {
        // Rotate features every 10 seconds
        const features = document.querySelectorAll('.feature');
        let currentIndex = 0;

        setInterval(() => {
            features[currentIndex].style.transform = 'scale(1.05)';
            features[currentIndex].style.background = '#3742fa';
            features[currentIndex].style.color = 'white';
            
            setTimeout(() => {
                features[currentIndex].style.transform = 'scale(1)';
                features[currentIndex].style.background = '#f1f2f6';
                features[currentIndex].style.color = '#2f3542';
                currentIndex = (currentIndex + 1) % features.length;
            }, 2000);
        }, 3000);

        // Add floating animation to CTA button
        const ctaButton = document.querySelector('.cta-button');
        setInterval(() => {
            ctaButton.style.animation = 'none';
            setTimeout(() => {
                ctaButton.style.animation = 'pulse 0.5s ease-in-out';
            }, 10);
        }, 5000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PromotionalDisplay();
});

// Handle external data updates
window.updateTemplateData = (data) => {
    window.templateConfig = data;
    new PromotionalDisplay();
};